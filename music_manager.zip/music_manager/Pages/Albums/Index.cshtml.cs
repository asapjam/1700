using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;

using music_manager.Data;
using music_manager.Models;

namespace music_manager.Pages.Albums
{
    public class IndexModel : PageModel
    {
        // Create an AppDbContext, so we have a disposable doorway to the Database
        private readonly AppDbContext _context;
        private readonly ILogger<IndexModel> _logger;

        // Define Constructor, which takes a AppDbContext, so we can communicate w/ DB
        public IndexModel(AppDbContext context, ILogger<IndexModel> logger)
        {
            _context = context;
            _logger = logger;
        }

        // Define an empty List of Albums
        public List<Album> Albums { get; private set; } = new();

        // Fill that list with the existing entries in the Database.
        public async Task<IActionResult> OnGetAsync()
        {
            try
            {
                Albums = await _context.Albums
                    .AsNoTracking()
                    .Include(b => b.Songs)
                    .Include(b => b.Artist)
                    .OrderBy(b => b.Name)
                    .ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while retrieving albums.");
                ModelState.AddModelError(string.Empty, "An error occurred while retrieving albums. Please try again later.");
            }
            return Page();
        }
    }
}
